//
//  flashcardsData.swift
//  XuConneHW5
//
//  Created by Connie Xu on 11/3/21.
//

import Foundation

import UIKit

class flashcardsData: NSObject {
    static var flashcardsModel: FlashcardsModel! = FlashcardsModel()
}
